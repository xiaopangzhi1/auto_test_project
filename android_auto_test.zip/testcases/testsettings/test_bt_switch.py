import pytest
import allure
from pages.settings_page.bt_switch_page import btSwitchPage



@allure.feature("bt开关测试")
class TestbtSwitch:
    """搜索蓝牙测试"""

    @allure.story("bt开关循环点击")
    @allure.severity("critical")
    def test_bt_switch(self, device):
        """测试bt开关循环点击10次"""
        d = btSwitchPage(device)

        # 启动设置应用
        d.open_settings()
        d.click_Connected_devices()
        # 循环搜索蓝牙 10 次
        for i in range(10):
            with allure.step(f"第 {i+1} 次搜索蓝牙"):
                d.click_Pair_new_device()
                d.back()
        # 验证操作完成
        d.back().back().home()