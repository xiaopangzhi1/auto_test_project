import pytest
import allure
from pages.settings_page.wifi_switch_page import WifiSwitchPage



@allure.feature("WiFi开关测试")
class TestWifiSwitch:
    """WiFi开关测试"""

    @allure.story("WiFi开关循环点击")
    @allure.severity("critical")
    def test_wifi_switch(self, device):
        """测试WiFi开关循环点击10次"""
        d = WifiSwitchPage(device)

        # 启动设置应用
        d.open_settings()
        d.click_Network_internet()
        d.click_Internet()
        # 循环点击 WiFi 开关 10 次
        for i in range(10):
            with allure.step(f"第 {i+1} 次点击 WiFi 开关"):
                d.click_wifiswitch()
        # 验证操作完成
        d.back().back().home()