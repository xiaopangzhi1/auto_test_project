import pytest
import uiautomator2 as u2
import time
import os
import allure


@pytest.fixture(scope="session")
def device():
    """设备连接夹具"""
    from config.device_config import DEVICE_CONFIG
    
    # 检查离线模式
    offline_mode = os.environ.get("OFFLINE_MODE", "").lower() == "true"
    if offline_mode:
        print("📴 离线模式启用，使用模拟设备")
        # 创建一个模拟设备对象
        class MockDevice:
            def __getattr__(self, name):
                return lambda *args, **kwargs: None
            def screenshot(self, path):
                print(f"模拟截图: {path}")
                # 创建一个空文件
                open(path, 'w').close()
            def info(self):
                return {"screenOn": True}
            def screen_on(self):
                pass
            def back(self):
                pass
            def home(self):
                pass
        
        d = MockDevice()
        yield d
        return

    if DEVICE_CONFIG.get("serial"):
        d = u2.connect(DEVICE_CONFIG["serial"])
    elif DEVICE_CONFIG.get("host"):
        d = u2.connect(DEVICE_CONFIG["host"])
    elif DEVICE_CONFIG.get("devices"):
        # 多设备模式，取第一个设备
        first_device = DEVICE_CONFIG["devices"][0]
        if first_device.get("serial"):
            d = u2.connect(first_device["serial"])
        elif first_device.get("host"):
            d = u2.connect(first_device["host"])
        else:
            raise ValueError("设备配置错误")
    else:
        raise ValueError("请在 config/device_config.py 中配置设备信息")

    # 确保屏幕唤醒（防止屏幕熄灭导致通信失败）
    wake_up_device(d)

    yield d


def wake_up_device(d):
    """唤醒设备屏幕"""
    try:
        screen_on = d.info.get("screenOn", True)
        if not screen_on:
            d.screen_on()
            time.sleep(0.5)
        print(f"设备已唤醒，屏幕状态: {d.info.get('screenOn', 'unknown')}")
    except Exception as e:
        print(f"唤醒设备时出现警告: {e}")


@pytest.fixture(scope="function", autouse=True)
def ensure_screen_on(device):
    """每个用例执行前确保屏幕唤醒"""
    try:
        screen_on = device.info.get("screenOn", True)
        if not screen_on:
            device.screen_on()
            time.sleep(0.5)
    except:
        pass
    yield


@pytest.fixture(autouse=True)
def screenshot_on_failure(request, device):
    """失败时自动截图"""
    yield
    if request.node.rep_call.failed:
        os.makedirs("screenshots", exist_ok=True)
        screenshot_path = f"screenshots/{request.node.name}_{int(time.time())}.png"
        device.screenshot(screenshot_path)
        allure.attach.file(
            screenshot_path,
            name="失败截图",
            attachment_type=allure.attachment_type.PNG
        )


@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_runtest_makereport(item, call):
    """获取用例执行结果"""
    outcome = yield
    rep = outcome.get_result()
    setattr(item, "rep_" + rep.when, rep)
