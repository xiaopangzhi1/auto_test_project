from pages.base_page import BasePage
from loguru import logger
import time
import sys


# 配置 loguru 输出（立即刷新，不缓冲）
logger.remove()
logger.add(
    sys.stderr,
    format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <level>{message}</level>",
    level="INFO",
    enqueue=False,  # 禁用队列，确保实时输出
)

class WifiSwitchPage(BasePage):
    """设置应用页面对象"""
    
    def __init__(self, d):
        super().__init__(d)

        # 元素定位器
        self.Network_internet = {"text": "Network & internet"}
        self.Internet = {"text": "Internet"}
        self.wifiswitch = {"resourceId": "com.android.settings:id/switchWidget"}

    def open_settings(self):
        """启动设置应用"""
        logger.info("启动设置应用")
        self.d.app_stop('com.android.settings')
        time.sleep(1)
        self.d.app_start('com.android.settings')
        time.sleep(3)
        logger.info("等待3秒完成")
        return self

    def click_Network_internet(self):
        """点击 Network & internet"""
        if self.is_visible(self.Network_internet, timeout=5):
            self.click(self.Network_internet, "Network & internet")
            logger.info("点击 Network & internet 成功")
        else:
            logger.error("设置打开异常：未检测到 Network & internet 元素")
            raise AssertionError("设置打开异常：未检测到 Network & internet 元素")

    def click_Internet(self):
        """点击 Internet"""
        if self.is_visible(self.Internet, timeout=5):
            self.click(self.Internet, "Internet")
            logger.info("点击 Internet 成功")
        else:
            logger.error("未检测到 Internet 元素")
            raise AssertionError("未检测到 Internet 元素")

    def click_wifiswitch(self):
        """点击 WiFi 开关"""
        if self.is_visible(self.wifiswitch, timeout=5):
            logger.info("检测到 wifiswitch 开关，点击")
            self.click(self.wifiswitch, "wifiswitch开关")
            time.sleep(5)

        else:
            logger.error("未检测到 wifiswitch 开关")
            raise AssertionError("未检测到 wifiswitch 开关")

        return self

    def test_wifi_switch(self):
        """测试WiFi开关（点击一次并返回）"""
        self.click_Network_internet()
        self.click_Internet()
        self.click_wifiswitch()
        self.back()
        return self
