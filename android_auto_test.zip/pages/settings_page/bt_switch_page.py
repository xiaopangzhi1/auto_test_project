from pages.base_page import BasePage
from loguru import logger
import time
import sys


# 配置 loguru 输出（立即刷新，不缓冲）
logger.remove()
logger.add(
    sys.stderr,
    format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <level>{message}</level>",
    level="INFO",
    enqueue=False,  # 禁用队列，确保实时输出
)

class btSwitchPage(BasePage):
    """设置应用页面对象"""
    
    def __init__(self, d):
        super().__init__(d)

        # 元素定位器
        self.Connected_devices = {"text": "Connected devices"}
        self.Pair_new_device = {"text": "Pair new device"}

    def open_settings(self):
        """启动设置应用"""
        logger.info("启动设置应用")
        self.d.app_stop('com.android.settings')
        time.sleep(1)
        self.d.app_start('com.android.settings')
        time.sleep(3)
        logger.info("等待3秒完成")
        return self

    def click_Connected_devices(self):
        """点击 Connected_devices"""
        if self.is_visible(self.Connected_devices, timeout=5):
            self.click(self.Connected_devices, "Connected devices")
            logger.info("点击 Connected devices 成功")
        else:
            logger.error("设置打开异常：未检测到 Connected devices 元素")
            raise AssertionError("设置打开异常：未检测到 Connected devices 元素")

    def click_Pair_new_device(self):
        """点击 Pair new device 按钮"""
        if self.is_visible(self.Pair_new_device, timeout=5):
            # 元素已出现，直接点击，无需再次等待
            self.click(self.Pair_new_device, description="Pair new device 按钮")
            time.sleep(5)
            logger.info("点击 Pair new device 成功")
        else:
            raise AssertionError("未检测到 Pair new device 元素")

