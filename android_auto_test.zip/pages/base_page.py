import time
from loguru import logger
import os

class BasePage:
    def __init__(self, d):
        self.d = d
        self.max_retries = 3
        self.retry_interval = 1

    def _retry(self, func, *args, **kwargs):
        last_exception = None
        for attempt in range(self.max_retries):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                last_exception = e
                logger.warning(f"操作失败，重试 {attempt + 1}/{self.max_retries}: {str(e)[:100]}")
                time.sleep(self.retry_interval)
        logger.error(f"操作失败，已重试 {self.max_retries} 次: {str(last_exception)[:200]}")
        raise last_exception

    def click(self, selector, description="", retry=True):
        desc = description or str(selector)
        logger.info(f"[点击] {desc}")

        def _click():
            element = self._find_element(selector)
            # 先等待元素出现
            if not element.wait(timeout=self.d.settings["wait_timeout"]):
                raise AssertionError(f"元素等待超时: {desc}")
            element.click()
            return True

        if retry:
            self._retry(_click)
        else:
            _click()
        logger.info(f"[点击成功] {desc}")
        return self

    def long_click(self, selector, duration=1.0, description=""):
        desc = description or str(selector)
        logger.info(f"[长按] {desc}, 时长: {duration}秒")
        element = self._find_element(selector)
        if not element.wait(timeout=self.d.settings["wait_timeout"]):
            raise AssertionError(f"元素等待超时: {desc}")
        element.long_click(duration=duration)
        logger.info(f"[长按成功] {desc}")
        return self

    def input_text(self, selector, text, description="", retry=True):
        desc = description or str(selector)
        logger.info(f"[输入] {desc} -> {text}")

        def _input():
            element = self._find_element(selector)
            if not element.wait(timeout=self.d.settings["wait_timeout"]):
                raise AssertionError(f"元素等待超时: {desc}")
            element.clear_text()
            element.set_text(text)
            time.sleep(0.5)
            actual_text = element.get_text()
            assert actual_text == text or text in actual_text, f"输入文本不匹配，期望: {text}, 实际: {actual_text}"
            return True

        if retry:
            self._retry(_input)
        else:
            _input()
        logger.info(f"[输入成功] {desc}")
        return self

    def get_text(self, selector, description=""):
        desc = description or str(selector)
        logger.info(f"[获取文本] {desc}")
        element = self._find_element(selector)
        if not element.wait(timeout=self.d.settings["wait_timeout"]):
            raise AssertionError(f"元素等待超时: {desc}")
        text = element.get_text()
        assert text is not None, f"获取文本失败: {desc}"
        logger.info(f"[获取文本成功] {desc} -> {text}")
        return text

    def is_visible(self, selector, timeout=None):
        """判断元素是否可见"""
        t = timeout or self.d.settings["wait_timeout"]
        try:
            element = self._get_element_object(selector)
            element.wait(timeout=t)
            return True
        except Exception as e:
            logger.debug(f"元素不可见: {selector}, 原因: {str(e)[:50]}")
            return False

    def wait_gone(self, selector, timeout=None):
        """等待元素消失"""
        t = timeout or self.d.settings["wait_timeout"]
        logger.info(f"[等待消失] {selector}, 超时: {t}秒")
        start_time = time.time()
        while time.time() - start_time < t:
            element = self._get_element_object(selector)
            if not element.exists:
                logger.info(f"[等待消失成功] {selector}")
                return True
            time.sleep(0.5)
        logger.warning(f"[等待消失超时] {selector}")
        return False

    def wait_and_click(self, selector, timeout=None, description=""):
        """等待元素出现后点击"""
        t = timeout or self.d.settings["wait_timeout"]
        desc = description or str(selector)
        logger.info(f"[等待并点击] {desc}, 超时: {t}秒")
        element = self._get_element_object(selector).wait(timeout=t)
        assert element is not None, f"等待元素超时: {desc}"
        element.click()
        logger.info(f"[等待并点击成功] {desc}")
        return self

    def wait(self, selector, timeout=None):
        """等待元素出现"""
        t = timeout or self.d.settings["wait_timeout"]
        logger.info(f"[等待] {selector}, 超时: {t}秒")
        element = self._get_element_object(selector).wait(timeout=t)
        assert element is not None, f"等待元素超时: {selector}"
        return self

    def _get_element_object(self, selector):
        """获取元素对象（不等待）"""
        if selector is None:
            raise ValueError("selector 不能为空")

        if isinstance(selector, str):
            selector_stripped = selector.strip()
            if selector_stripped.startswith("//") or selector_stripped.startswith("(//"):
                return self.d.xpath(selector_stripped)
            elif ":" in selector_stripped and "/" in selector_stripped:
                return self.d(resourceId=selector_stripped)
            elif "." in selector_stripped and not selector_stripped.startswith("."):
                return self.d(className=selector_stripped)
            else:
                return self.d(text=selector_stripped)

        elif isinstance(selector, dict):
            if not selector:
                raise ValueError("字典 selector 不能为空")
            return self.d(**selector)

        else:
            raise ValueError(f"不支持的 selector 类型: {type(selector)}")

    def swipe_up(self, duration=0.2):
        logger.info("[滑动] 向上滑动")
        h = self.d.window_size()[1]
        w = self.d.window_size()[0]
        assert h > 0 and w > 0, "获取屏幕尺寸失败"
        self.d.swipe(w/2, h*0.8, w/2, h*0.2, duration=duration)
        logger.info("[滑动成功] 向上滑动")
        return self

    def swipe_down(self, duration=0.2):
        logger.info("[滑动] 向下滑动")
        h = self.d.window_size()[1]
        w = self.d.window_size()[0]
        assert h > 0 and w > 0, "获取屏幕尺寸失败"
        self.d.swipe(w/2, h*0.2, w/2, h*0.8, duration=duration)
        logger.info("[滑动成功] 向下滑动")
        return self

    def swipe_left(self, duration=0.2):
        logger.info("[滑动] 向左滑动")
        h = self.d.window_size()[1]
        w = self.d.window_size()[0]
        assert h > 0 and w > 0, "获取屏幕尺寸失败"
        self.d.swipe(w*0.8, h/2, w*0.2, h/2, duration=duration)
        logger.info("[滑动成功] 向左滑动")
        return self

    def swipe_right(self, duration=0.2):
        logger.info("[滑动] 向右滑动")
        h = self.d.window_size()[1]
        w = self.d.window_size()[0]
        assert h > 0 and w > 0, "获取屏幕尺寸失败"
        self.d.swipe(w*0.2, h/2, w*0.8, h/2, duration=duration)
        logger.info("[滑动成功] 向右滑动")
        return self

    def back(self):
        logger.info("[返回] 执行返回操作")
        self.d.press("back")
        logger.info("[返回成功]")
        return self

    def home(self):
        logger.info("[主页] 回到主页")
        self.d.press("home")
        logger.info("[主页成功]")
        return self

    def screenshot(self, filename=None):
        os.makedirs("screenshots", exist_ok=True)
        if filename is None:
            filename = f"screenshot_{int(time.time())}.png"
        filepath = os.path.join("screenshots", filename)
        logger.info(f"[截图] {filepath}")
        self.d.screenshot(filepath)
        logger.info(f"[截图成功] {filepath}")
        return filepath

    def assert_element_exists(self, selector, description="", timeout=None):
        desc = description or str(selector)
        t = timeout or self.d.settings["wait_timeout"]
        logger.info(f"[断言存在] {desc}, 超时: {t}秒")
        element = self._find_element(selector)
        if not element.wait(timeout=t):
            raise AssertionError(f"元素等待超时: {desc}")
        logger.info(f"[断言成功] 元素存在: {desc}")
        return self

    def assert_element_text(self, selector, expected_text, description="", timeout=None):
        desc = description or str(selector)
        t = timeout or self.d.settings["wait_timeout"]
        logger.info(f"[断言文本] {desc}, 期望: {expected_text}, 超时: {t}秒")
        element = self._find_element(selector)
        if not element.wait(timeout=t):
            raise AssertionError(f"元素等待超时: {desc}")
        actual_text = element.get_text()
        assert actual_text == expected_text, f"文本不匹配，期望: {expected_text}, 实际: {actual_text}"
        logger.info(f"[断言成功] 文本匹配: {desc}")
        return self

    def _find_element(self, selector):
        """
        查找元素，支持多种定位方式
        返回元素对象（不等待）
        """
        if selector is None:
            raise ValueError("selector 不能为空")

        if isinstance(selector, str):
            selector_stripped = selector.strip()
            if selector_stripped.startswith("//") or selector_stripped.startswith("(//"):
                return self.d.xpath(selector_stripped)
            elif ":" in selector_stripped and "/" in selector_stripped:
                return self.d(resourceId=selector_stripped)
            elif "." in selector_stripped and not selector_stripped.startswith("."):
                return self.d(className=selector_stripped)
            else:
                return self.d(text=selector_stripped)

        elif isinstance(selector, dict):
            if not selector:
                raise ValueError("字典 selector 不能为空")
            return self.d(**selector)

        else:
            raise ValueError(f"不支持的 selector 类型: {type(selector)}")