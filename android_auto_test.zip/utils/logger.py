"""
统一的日志配置模块
提供控制台和文件日志输出，支持彩色显示和错误处理
"""

import os
import sys
from loguru import logger

# 创建日志目录
os.makedirs("logs", exist_ok=True)

# 移除默认配置
logger.remove()

# 控制台输出配置（彩色，适合开发调试）
logger.add(
    sys.stderr,
    format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | "
           "<level>{level: <8}</level> | "
           "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> | "
           "<level>{message}</level>",
    level="INFO",
    colorize=True,
    backtrace=True,
    diagnose=True,
    enqueue=False,  # 禁用队列，确保实时输出
)

# 文件输出配置（详细，适合生产环境）
logger.add(
    "logs/{time:YYYY-MM-DD_HH-mm-ss}.log",
    format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} | {message}",
    level="DEBUG",  # 文件记录更详细的日志
    rotation="500 MB",
    retention="7 days",
    compression="zip",
    encoding="utf-8",
    enqueue=True,  # 启用队列，避免文件写入阻塞
)

# 错误日志单独文件
logger.add(
    "logs/error_{time:YYYY-MM-DD}.log",
    format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} | {message}",
    level="ERROR",
    rotation="100 MB",
    retention="30 days",
    compression="zip",
    encoding="utf-8",
    filter=lambda record: record["level"].name == "ERROR",
)

# 导出 logger 供其他模块使用
__all__ = ["logger"]

# 使用示例：
# from utils.logger import logger
# logger.info("这是一条信息日志")
# logger.warning("这是一条警告日志")
# logger.error("这是一条错误日志")
# logger.debug("这是一条调试日志")