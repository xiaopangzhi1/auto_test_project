"""
美化 pytest-html 报告
提供筛选功能、样式和更好的展示效果
"""

def get_custom_css():
    """自定义 CSS 样式"""
    return """
    <style>
        /* 整体样式 */
        body {
            font-family: 'Segoe UI', 'Microsoft YaHei', Arial, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            margin: 0;
            padding: 20px;
            min-height: 100vh;
            color: #333;
        }

        /* 报告标题 */
        h1 {
            color: #2c3e50;
            border-bottom: 3px solid #3498db;
            padding-bottom: 15px;
            margin-bottom: 25px;
            font-size: 32px;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            gap: 15px;
        }
        h1:before {
            content: "📊";
            font-size: 36px;
        }

        /* 顶部信息栏 */
        .report-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 25px;
            flex-wrap: wrap;
            gap: 20px;
        }

        /* 统计卡片容器 */
        .stats-container {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }

        /* 统计卡片 */
        .summary-card {
            display: inline-block;
            padding: 20px 30px;
            border-radius: 12px;
            color: white;
            font-weight: bold;
            min-width: 120px;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
            cursor: pointer;
            position: relative;
            overflow: hidden;
        }
        .summary-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.3);
        }
        .summary-card:before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: rgba(255,255,255,0.3);
        }
        .passed-card { background: linear-gradient(135deg, #27ae60, #2ecc71); }
        .failed-card { background: linear-gradient(135deg, #e74c3c, #c0392b); }
        .skipped-card { background: linear-gradient(135deg, #f39c12, #e67e22); }
        .total-card { background: linear-gradient(135deg, #3498db, #2980b9); }
        .pass-rate-card { background: linear-gradient(135deg, #9b59b6, #8e44ad); }

        /* 卡片内部数字 */
        .summary-card div:last-child {
            font-size: 32px;
            margin-top: 10px;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.2);
        }

        /* 筛选按钮 */
        .filter-container {
            display: flex;
            gap: 10px;
            align-items: center;
            background: white;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        .filter-label {
            font-weight: bold;
            color: #7f8c8d;
            margin-right: 10px;
            font-size: 16px;
        }
        .filter-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.3s;
            opacity: 0.8;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .filter-btn:hover {
            opacity: 1;
            transform: scale(1.05);
        }
        .filter-btn.active {
            opacity: 1;
            box-shadow: 0 0 15px rgba(0,0,0,0.3);
            transform: scale(1.05);
        }
        .filter-all { background: #3498db; color: white; }
        .filter-passed { background: #27ae60; color: white; }
        .filter-failed { background: #e74c3c; color: white; }
        .filter-skipped { background: #f39c12; color: white; }

        /* 测试结果表格 */
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
            margin-top: 20px;
        }
        th {
            background: linear-gradient(135deg, #34495e, #2c3e50);
            color: white;
            padding: 18px 20px;
            text-align: left;
            font-weight: 600;
            font-size: 16px;
            position: sticky;
            top: 0;
        }
        td {
            padding: 16px 20px;
            border-bottom: 1px solid #eee;
            font-size: 14px;
        }
        tr {
            transition: all 0.2s ease;
        }
        tr:hover {
            background: #f8f9fa;
            transform: scale(1.002);
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        tr.hidden {
            display: none;
        }

        /* 状态标签 */
        .status-passed {
            color: #27ae60;
            font-weight: bold;
            background: rgba(39, 174, 96, 0.1);
            padding: 5px 12px;
            border-radius: 20px;
            display: inline-block;
        }
        .status-failed {
            color: #e74c3c;
            font-weight: bold;
            background: rgba(231, 76, 60, 0.1);
            padding: 5px 12px;
            border-radius: 20px;
            display: inline-block;
        }
        .status-skipped {
            color: #f39c12;
            font-weight: bold;
            background: rgba(243, 156, 18, 0.1);
            padding: 5px 12px;
            border-radius: 20px;
            display: inline-block;
        }

        /* 环境信息 */
        .env-info {
            background: white;
            padding: 25px;
            border-radius: 12px;
            margin-bottom: 25px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
            border-left: 5px solid #3498db;
        }
        .env-info h3 {
            margin: 0 0 20px 0;
            color: #2c3e50;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
            font-size: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .env-info h3:before {
            content: "⚙️";
        }
        .env-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 15px;
        }
        .env-item {
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            padding: 15px 20px;
            border-radius: 8px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: all 0.3s ease;
            border-left: 4px solid #3498db;
        }
        .env-item:hover {
            transform: translateX(5px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .env-label {
            color: #7f8c8d;
            font-size: 14px;
            font-weight: 500;
        }
        .env-value {
            color: #2c3e50;
            font-weight: bold;
            font-size: 15px;
            text-align: right;
        }

        /* 进度条 */
        .progress-bar {
            width: 100%;
            height: 12px;
            background: #ecf0f1;
            border-radius: 6px;
            overflow: hidden;
            margin-top: 10px;
            box-shadow: inset 0 1px 3px rgba(0,0,0,0.2);
        }
        .progress-fill {
            height: 100%;
            transition: width 0.5s ease;
            float: left;
        }
        .progress-fill.passed { background: linear-gradient(90deg, #27ae60, #2ecc71); }
        .progress-fill.failed { background: linear-gradient(90deg, #e74c3c, #c0392b); }
        .progress-fill.skipped { background: linear-gradient(90deg, #f39c12, #e67e22); }

        /* 操作按钮 */
        .action-buttons {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        .action-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
            background: #2c3e50;
            color: white;
        }
        .action-btn:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }
        .action-btn.copy { background: #3498db; }
        .action-btn.export { background: #9b59b6; }
        .action-btn.refresh { background: #27ae60; }

        /* 耗时显示 */
        .duration-cell {
            position: relative;
        }
        .duration-bar {
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            background: rgba(52, 152, 219, 0.1);
            border-radius: 4px;
            z-index: 0;
        }
        .duration-text {
            position: relative;
            z-index: 1;
        }

        /* 响应式 */
        @media (max-width: 768px) {
            body {
                padding: 10px;
            }
            .report-header {
                flex-direction: column;
            }
            .stats-container {
                width: 100%;
                justify-content: center;
            }
            .summary-card {
                min-width: calc(50% - 15px);
                padding: 15px;
            }
            .env-grid {
                grid-template-columns: 1fr;
            }
            table {
                font-size: 13px;
            }
            th, td {
                padding: 12px 10px;
            }
        }

        /* 动画 */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .summary-card, .env-item, table {
            animation: fadeIn 0.5s ease forwards;
        }

        /* 暗色模式切换 */
        .theme-toggle {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #2c3e50;
            color: white;
            border: none;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            cursor: pointer;
            font-size: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            z-index: 1000;
            transition: all 0.3s;
        }
        .theme-toggle:hover {
            transform: rotate(30deg);
        }

        /* 暗色模式 */
        body.dark-mode {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #e0e0e0;
        }
        body.dark-mode .env-info,
        body.dark-mode table,
        body.dark-mode .filter-container {
            background: #2c3e50;
            color: #e0e0e0;
        }
        body.dark-mode .env-item {
            background: linear-gradient(135deg, #34495e, #2c3e50);
        }
        body.dark-mode td {
            border-color: #4a6278;
        }
        body.dark-mode tr:hover {
            background: #34495e;
        }
    </style>
    """


def get_env_info_script(device_info=None, android_version=None, app_version=None, tester=None):
    """环境信息 JavaScript - 从 pytest metadata 获取准确数据"""
    return f"""
    <script>
        document.addEventListener('DOMContentLoaded', function() {{
            // 从表格行获取实际统计数据（更可靠）
            var rows = document.querySelectorAll('table.results tbody tr');
            var passed = 0, failed = 0, skipped = 0;

            rows.forEach(function(row) {{
                if (row.classList.contains('passed')) passed++;
                else if (row.classList.contains('failed')) failed++;
                else if (row.classList.contains('skipped')) skipped++;
            }});

            var total = passed + failed + skipped;
            var passRate = total > 0 ? ((passed / total) * 100).toFixed(1) : '0.0';

            // 填充环境信息
            var testTime = document.getElementById('test-time');
            if (testTime) {{
                testTime.textContent = new Date().toLocaleString('zh-CN');
            }}

            var deviceEl = document.getElementById('env-device');
            if (deviceEl && '{device_info}') {{
                deviceEl.textContent = '{device_info}';
            }}

            var androidEl = document.getElementById('env-android');
            if (androidEl && '{android_version}') {{
                androidEl.textContent = '{android_version}';
            }}

            var appEl = document.getElementById('env-app');
            if (appEl && '{app_version}') {{
                appEl.textContent = '{app_version}';
            }}

            var testerEl = document.getElementById('env-tester');
            if (testerEl && '{tester}') {{
                testerEl.textContent = '{tester}';
            }}

            var passRateEl = document.getElementById('env-passrate');
            if (passRateEl) {{
                passRateEl.textContent = passRate + '%';
            }}

            // 显示统计卡片
            var statsDiv = document.createElement('div');
            statsDiv.className = 'stats-container';
            statsDiv.innerHTML =
                '<div class="summary-card total-card">总计<div style="font-size:32px;margin-top:10px;">' + total + '</div></div>' +
                '<div class="summary-card passed-card">通过<div style="font-size:32px;margin-top:10px;">' + passed + '</div></div>' +
                '<div class="summary-card failed-card">失败<div style="font-size:32px;margin-top:10px;">' + failed + '</div></div>' +
                '<div class="summary-card skipped-card">跳过<div style="font-size:32px;margin-top:10px;">' + skipped + '</div></div>' +
                '<div class="summary-card pass-rate-card">通过率<div style="font-size:32px;margin-top:10px;">' + passRate + '%</div></div>';

            var h1 = document.querySelector('h1');
            if (h1) {{
                h1.after(statsDiv);
            }}

            // 添加进度条
            var progressDiv = document.createElement('div');
            progressDiv.style.cssText = 'margin-top:15px;padding:15px;background:white;border-radius:8px;box-shadow:0 2px 10px rgba(0,0,0,0.1);';
            progressDiv.innerHTML =
                '<div style="display:flex;justify-content:space-between;margin-bottom:5px;font-size:13px;color:#7f8c8d;">' +
                '<span>测试进度</span><span>' + passRate + '%</span></div>' +
                '<div class="progress-bar">' +
                '<div class="progress-fill passed" style="width:' + (passed/total*100) + '%;"></div>' +
                '<div class="progress-fill failed" style="width:' + (failed/total*100) + '%;"></div>' +
                '<div class="progress-fill skipped" style="width:' + (skipped/total*100) + '%;"></div>' +
                '</div>';

            statsDiv.after(progressDiv);

            // 添加操作按钮
            var actionDiv = document.createElement('div');
            actionDiv.className = 'action-buttons';
            actionDiv.innerHTML =
                '<button class="action-btn copy" onclick="copyEnvInfo()"><span>📋</span>复制环境信息</button>' +
                '<button class="action-btn export" onclick="exportReport()"><span>📥</span>导出报告</button>' +
                '<button class="action-btn refresh" onclick="location.reload()"><span>🔄</span>刷新</button>';
            
            var envInfo = document.querySelector('.env-info');
            if (envInfo) {{
                envInfo.after(actionDiv);
            }}

            // 添加暗色模式切换按钮
            var themeBtn = document.createElement('button');
            themeBtn.className = 'theme-toggle';
            themeBtn.innerHTML = '🌙';
            themeBtn.title = '切换暗色模式';
            themeBtn.onclick = toggleDarkMode;
            document.body.appendChild(themeBtn);

            // 添加耗时可视化
            addDurationVisualization();
        }});

        // 暗色模式切换
        function toggleDarkMode() {{
            document.body.classList.toggle('dark-mode');
            var btn = document.querySelector('.theme-toggle');
            btn.innerHTML = document.body.classList.contains('dark-mode') ? '☀️' : '🌙';
            btn.title = document.body.classList.contains('dark-mode') ? '切换亮色模式' : '切换暗色模式';
            
            // 保存偏好
            localStorage.setItem('darkMode', document.body.classList.contains('dark-mode'));
        }}

        // 复制环境信息
        function copyEnvInfo() {{
            var envItems = document.querySelectorAll('.env-item');
            var text = '测试环境信息\\n';
            envItems.forEach(function(item) {{
                var label = item.querySelector('.env-label').textContent;
                var value = item.querySelector('.env-value').textContent;
                text += label + ': ' + value + '\\n';
            }});
            
            navigator.clipboard.writeText(text).then(function() {{
                alert('环境信息已复制到剪贴板！');
            }}, function(err) {{
                console.error('复制失败: ', err);
                alert('复制失败，请手动复制');
            }});
        }}

        // 导出报告（简单实现）
        function exportReport() {{
            var html = document.documentElement.outerHTML;
            var blob = new Blob([html], {{type: 'text/html'}});
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            a.download = '测试报告_' + new Date().toISOString().slice(0,10) + '.html';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }}

        // 添加耗时可视化
        function addDurationVisualization() {{
            var durationCells = document.querySelectorAll('td:nth-child(3)'); // 假设第3列是耗时
            if (durationCells.length === 0) return;
            
            var maxDuration = 0;
            var durations = [];
            
            durationCells.forEach(function(cell) {{
                var text = cell.textContent.trim();
                var seconds = 0;
                
                // 解析时间格式 00:00:15
                if (text.includes(':')) {{
                    var parts = text.split(':').reverse();
                    for (var i = 0; i < parts.length; i++) {{
                        seconds += parseInt(parts[i] || 0) * Math.pow(60, i);
                    }}
                }} else {{
                    seconds = parseFloat(text) || 0;
                }}
                
                durations.push(seconds);
                if (seconds > maxDuration) maxDuration = seconds;
            }});
            
            if (maxDuration === 0) return;
            
            durationCells.forEach(function(cell, index) {{
                var percent = (durations[index] / maxDuration) * 100;
                if (percent > 0) {{
                    cell.classList.add('duration-cell');
                    cell.innerHTML = '<div class="duration-bar" style="width:' + percent + '%;"></div>' +
                                    '<div class="duration-text">' + cell.textContent + '</div>';
                }}
            }});
        }}

        // 初始化暗色模式偏好
        if (localStorage.getItem('darkMode') === 'true') {{
            document.body.classList.add('dark-mode');
        }}
    </script>
    """


def get_filter_script():
    """筛选功能 JavaScript"""
    return """
    <script>
        // 筛选功能
        function filterTests(status) {
            var rows = document.querySelectorAll('table.results tbody tr');
            var buttons = document.querySelectorAll('.filter-btn');

            // 更新按钮状态
            buttons.forEach(function(btn) {
                btn.classList.remove('active');
            });
            document.querySelector('.filter-' + status).classList.add('active');

            // 筛选行（跳过表头）
            rows.forEach(function(row) {
                if (status === 'all') {
                    row.classList.remove('hidden');
                } else {
                    if (row.classList.contains(status)) {
                        row.classList.remove('hidden');
                    } else {
                        row.classList.add('hidden');
                    }
                }
            });

            // 更新统计卡片（仅显示相关数量）
            updateStatsDisplay(status);
        }

        function updateStatsDisplay(filter) {
            var rows = document.querySelectorAll('table.results tbody tr');
            var passed = 0, failed = 0, skipped = 0;

            rows.forEach(function(row) {
                if (!row.classList.contains('hidden')) {
                    if (row.classList.contains('passed')) passed++;
                    else if (row.classList.contains('failed')) failed++;
                    else if (row.classList.contains('skipped')) skipped++;
                }
            });

            var total = passed + failed + skipped;
            var passRate = total > 0 ? ((passed / total) * 100).toFixed(1) : '0.0';

            // 更新显示
            document.querySelector('.total-card div:last-child').textContent = total;
            document.querySelector('.passed-card div:last-child').textContent = passed;
            document.querySelector('.failed-card div:last-child').textContent = failed;
            document.querySelector('.skipped-card div:last-child').textContent = skipped;
            document.querySelector('.pass-rate-card div:last-child').textContent = passRate + '%';
        }

        // 初始化
        document.addEventListener('DOMContentLoaded', function() {
            // 添加筛选按钮
            var filterDiv = document.createElement('div');
            filterDiv.className = 'filter-container';
            filterDiv.innerHTML =
                '<span class="filter-label">筛选:</span>' +
                '<button class="filter-btn filter-all active" onclick="filterTests(\\'all\\')">全部</button>' +
                '<button class="filter-btn filter-passed" onclick="filterTests(\\'passed\\')">通过</button>' +
                '<button class="filter-btn filter-failed" onclick="filterTests(\\'failed\\')">失败</button>' +
                '<button class="filter-btn filter-skipped" onclick="filterTests(\\'skipped\\')">跳过</button>';

            var statsContainer = document.querySelector('.stats-container');
            if (statsContainer) {
                statsContainer.after(filterDiv);
            }
        });
    </script>
    """


def get_env_html():
    """环境信息 HTML 结构"""
    return """
    <div class="env-info">
        <h3>测试环境</h3>
        <div class="env-grid">
            <div class="env-item">
                <span class="env-label">设备</span>
                <span class="env-value" id="env-device">-</span>
            </div>
            <div class="env-item">
                <span class="env-label">Android版本</span>
                <span class="env-value" id="env-android">-</span>
            </div>
            <div class="env-item">
                <span class="env-label">App版本</span>
                <span class="env-value" id="env-app">-</span>
            </div>
            <div class="env-item">
                <span class="env-label">测试人员</span>
                <span class="env-value" id="env-tester">-</span>
            </div>
            <div class="env-item">
                <span class="env-label">运行时间</span>
                <span class="env-value" id="test-time">-</span>
            </div>
            <div class="env-item">
                <span class="env-label">通过率</span>
                <span class="env-value" id="env-passrate">-</span>
            </div>
        </div>
    </div>
    """


def pytest_html_results_summary(prefix, summary, postfix, device_info=None, android_version=None, app_version=None, tester=None):
    """
    pytest_html_results_summary 钩子配置

    用法:
        from utils.report_style import pytest_html_results_summary

        def pytest_html_results_summary(prefix, summary, postfix):
            pytest_html_results_summary(prefix, summary, postfix,
                device_info="0123456789ABCDEF",
                android_version="12",
                app_version="1.0.0",
                tester="自动化测试")
    """
    prefix.extend([
        get_custom_css(),
        get_env_html(),
        get_env_info_script(device_info, android_version, app_version, tester),
        get_filter_script()
    ])
