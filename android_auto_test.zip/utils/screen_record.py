import time
import os
from loguru import logger

class ScreenRecorder:
    def __init__(self, device):
        self.device = device
        self.recording = False
        os.makedirs("screenshots", exist_ok=True)
    
    def start(self):
        if not self.recording:
            logger.info("[录屏] 开始录屏")
            self.device.screenrecord.start()
            self.recording = True
    
    def stop(self, filename=None):
        if self.recording:
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            filename = filename or f"screen_record_{timestamp}.mp4"
            filepath = os.path.join("screenshots", filename)
            self.device.screenrecord.stop(filepath)
            self.recording = False
            logger.info(f"[录屏] 停止录屏，文件已保存: {filepath}")
            return filepath